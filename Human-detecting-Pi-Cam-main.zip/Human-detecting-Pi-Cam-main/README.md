# Human-detecting-Pi-Cam
Human Detecting security Camera using OpenCV trained on kaggle models
